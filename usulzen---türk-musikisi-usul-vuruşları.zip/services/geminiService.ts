// AI features have been removed from this application.
// This file is kept as a placeholder to avoid import errors if referenced elsewhere, 
// though all references should have been removed.

export const getUsulInfo = async (usulName: string): Promise<string> => {
    return Promise.resolve("");
};

export const generateUsulFromDescription = async (description: string): Promise<any | null> => {
    return Promise.resolve(null);
};
